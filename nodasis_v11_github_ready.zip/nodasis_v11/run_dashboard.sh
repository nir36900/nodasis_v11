#!/bin/bash
source venv/bin/activate
streamlit run frontend/dashboard_app.py